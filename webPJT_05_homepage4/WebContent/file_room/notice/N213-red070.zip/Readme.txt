﻿==============================================
	한국어 설명
==============================================
Microsoft의 NET Framework 4.6 버전이 낮을 경우 설치가 되지 않습니다
버전이 낮을 경우 아래 다운링크를 통하여 Net Framework 를 설치 후 접속기 설치를 해주세요.

다운링크:
https://www.microsoft.com/ko-KR/download/details.aspx?id=48130

------------------------------------------------------------

NET Framework 를 업데이트 후에 설치가 안될 경우 아래 링크를 통해 다운로드하여 사용해주세요.
http://update.vpnauction.com/download/lsw/red070-re.zip


==============================================
	中文说明
==============================================
如果安装失败，可能是缺乏微软的net framework 4.6

下载链接：
https://www.microsoft.com/zh-CN/download/details.aspx?id=48130

------------------------------------------------------------

如果还是安装失败请下载免安装版本：
http://update.vpnauction.com/download/lsw/red070-re.zip
